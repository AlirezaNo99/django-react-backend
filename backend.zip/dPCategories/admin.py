
from django.contrib import admin
from .models import DPCategory


admin.site.register(DPCategory)
