from django.apps import AppConfig


class DigitalproductsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'digitalProducts'
