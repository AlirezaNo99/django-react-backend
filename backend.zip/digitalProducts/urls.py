from django.urls import path
from .views import DigitalProductDetail, DigitalProductCount

urlpatterns = [
    path("digitalProducts/<int:pk>/", DigitalProductDetail.as_view(), name="digitalProduct-detail"),
    path("digitalProducts/", DigitalProductDetail.as_view(), name="digitalProduct-create"),
    path('digitalProducts/count/', DigitalProductCount.as_view(), name='digital-product-count'),

]