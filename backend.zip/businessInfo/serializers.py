from rest_framework import serializers
from .models import BusinessInfo 


class FooterInfoSerializer(serializers.ModelSerializer):

    class Meta:
        model = BusinessInfo
        fields = (
            "id",
            "aboutUsSummary",
            "logoDark",
            "logoLight",
            "address",
            "tel",
            "email",
            "postalCode",
        )

class HeaderInfoSerializer(serializers.ModelSerializer):

    class Meta:
        model = BusinessInfo
        fields = (
            "id",
            "logoDark",
            "logoLight",
        )
class AboutUsInfoSerializer(serializers.ModelSerializer):

    class Meta:
        model = BusinessInfo
        fields = (
            "id",
            "name",
            "aboutUsImage",
            "aboutUs",
        )

class ContactUsInfoSerializer(serializers.ModelSerializer):

    class Meta:
        model = BusinessInfo
        fields = (
            "id",
            "tel",
            "address",
            "email",
            "contactUsImage",
            "postalCode",
        )

class PoliciesInfoSerializer(serializers.ModelSerializer):

    class Meta:
        model = BusinessInfo
        fields = (
            "id",
            "policies",
            "policiesImage",
           
        )

    def create(self, validated_data):
        # Create the post with the validated data directly
        return BusinessInfo.objects.create(**validated_data)
