from django.contrib import admin
from .models import BusinessInfo


class BusinessInfoAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "name",
        "logoLight",
        "logoDark",
        "aboutUs",
        "aboutUsSummary",
        "aboutUsImage",
        "email",
        "tel",
        "postalCode",
        "address",
        "contactUsImage",
        "policies",
        "policiesImage",
        "created_at",  
        "updated_at",
      
    )


admin.site.register(BusinessInfo, BusinessInfoAdmin)
