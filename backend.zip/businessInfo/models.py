from django.db import models


class BusinessInfo(models.Model): 
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=150)
    logoDark=models.ImageField(upload_to='business/', null=True, blank=True)
    logoLight=models.ImageField(upload_to='business/', null=True, blank=True)
    aboutUs = models.TextField()
    aboutUsSummary = models.CharField(max_length=1000)
    aboutUsImage = models.ImageField(upload_to='business/', null=True, blank=True) 
    tel=models.IntegerField()
    postalCode=models.IntegerField()
    address = models.CharField(max_length=2000)
    email = models.CharField(max_length=500)
    contactUsImage = models.ImageField(upload_to='business/', null=True, blank=True)  
    policies = models.TextField()
    policiesImage = models.ImageField(upload_to='business/', null=True, blank=True)  
    created_at = models.DateTimeField(auto_now_add=True) 
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return self.name
